import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:provider/provider.dart';
// import '../providers/auth_provider.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _quote = '';
  String _joke = '';

  @override
  void initState() {
    super.initState();
    _fetchQuote();
    _fetchJoke();
  }

  Future<void> _fetchQuote() async {
    final response = await http.get(Uri.parse('https://dog.ceo/api/breeds/image/random'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _quote = data['message'];
      });
    }
  }

  Future<void> _fetchJoke() async {
    final response =
        await http.get(Uri.parse('https://official-joke-api.appspot.com/random_joke'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _joke = '${data['setup']} - ${data['punchline']}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(_quote),
            Text(_quote),
            SizedBox(height: 20),
            Text('Random Joke:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(_joke),
          ],
        ),
      ),
    );
  }
}
